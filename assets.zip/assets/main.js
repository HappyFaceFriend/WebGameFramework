var width = 800;
var height = 600;

var game = new Phaser.Game(width,height,Phaser.AUTO);


var TEST = {
	preload: function()	{
		game.load.image('player','assets/player.png');
		game.load.image('enemy','assets/enemy.png');
		game.load.image('bullet','assets/bullet.png');
		game.load.image('background','assets/background.png');
	},
	create: function()	{
		game.physics.startSystem(Phaser.Physics.ARCADE);
		this.wKey = game.input.keyboard.addKey(Phaser.Keyboard.W);
		this.aKey = game.input.keyboard.addKey(Phaser.Keyboard.A);
		this.sKey = game.input.keyboard.addKey(Phaser.Keyboard.S);
		this.dKey = game.input.keyboard.addKey(Phaser.Keyboard.D);
		this.rKey = game.input.keyboard.addKey(Phaser.Keyboard.R);
		this.spaceKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);

		this.spaceKey.onDown.add(this.shoot);
		this.rKey.onDown.add(this.shoot2);

		this.bg1=game.add.sprite(0,0,'background');
		this.bg2=game.add.sprite(width,0,'background');

		this.player = game.add.sprite(0,250,'player');
		this.player.anchor.setTo(0.5);
		this.bulletList=[];
		this.bulletList2=game.add.group();

		this.enemy = game.add.sprite(500,200,'enemy');
		this.enemy.anchor.setTo(0.5);
	    game.physics.enable(this.player, Phaser.Physics.ARCADE);
	    game.physics.enable(this.enemy, Phaser.Physics.ARCADE);
		this.enemy.body.immovable = true;
		this.player.body.collideWorldBounds=true;
		this.player.body.bounce.set(0.8);
	},
	update: function()	{
		game.physics.arcade.collide(this.player, this.enemy);

		this.bg1.x-=10;	
		this.bg2.x-=10;
		if(this.bg1.x <= 0-width)
			this.bg1.x+=width*2;
		if(this.bg2.x <= 0-width)
			this.bg2.x+=width*2;

		if(this.aKey.isDown)
			this.player.body.velocity.x-=10;
		if(this.dKey.isDown)
			this.player.body.velocity.x+=10;
		if(this.wKey.isDown)
			this.player.body.velocity.y-=10;
		if(this.sKey.isDown)
			this.player.body.velocity.y+=10;

		for(let i=0; i<this.bulletList.length; i++)	{
			this.bulletList[i].x+=10;
			if(game.physics.arcade.collide(this.bulletList[i], this.enemy))	{
				this.bulletList[i].destroy();
				this.bulletList.splice(i,1);
				i--;
			}
		}
		for(let i=0; i<this.bulletList2.children.length; i++)	{
			this.bulletList2.children[i].rotation = game.physics.arcade.moveToObject(
				this.bulletList2.children[i],this.enemy, 1000);
		}
		game.physics.arcade.collide(this.bulletList2, this.enemy, function(b,e){	//G vs S : S alwasy first
			e.destroy();
		});

	/*items = game.add.group();

    //  Items are rendered in the depth order in which they are added to the Group
    items.create(64, 100, 'atari1');
    card = items.create(240, 80, 'card');
    items.create(280, 100, 'atari2');*/
	},
	shoot: function()	{
		let b = game.add.sprite(TEST.player.x,TEST.player.y,'bullet');
		b.anchor.setTo(0.5);
	    game.physics.enable(b, Phaser.Physics.ARCADE);
		TEST.bulletList.push(b);
	},
	shoot2: function()	{
			console.log(TEST);
			for(let i=0; i<6; i++)
				game.time.events.add(Phaser.Timer.SECOND * 0.2 * i, TEST.shootB, TEST);
		},
	shootB: function(){
		let b = game.add.sprite(TEST.player.x,TEST.player.y,'bullet');
		b.anchor.setTo(0.5);
	    game.physics.enable(b, Phaser.Physics.ARCADE);
		this.bulletList2.add(b)
	}
};



game.state.add('TEST',TEST);

game.state.start('TEST');