var width = 800;
var height = 600;

var game = new Phaser.Game(width,height,Phaser.AUTO);


var TEST = {
	preload: function()	{
		game.load.image('player','assets/player.png');
		game.load.image('enemy','assets/enemy.png');
		game.load.image('bullet','assets/bullet.png');
		game.load.image('background','assets/background.png');
		game.load.image('floor','assets/floor.png');
		game.load.image('item','assets/item.png');
		game.load.image('effect','assets/effect.png');
	},
	create: function()	{	
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.physics.arcade.gravity.y=3000;

	    game.add.tileSprite(0, 0, 1600, 800, 'background');
	    game.world.setBounds(0, 0,  1600, 800);

		this.player = game.add.sprite(400,300,'player');
		this.player.anchor.setTo(0.5);
		game.physics.enable(this.player, Phaser.Physics.ARCADE);
		this.player.body.collideWorldBounds=true;
		//this.player.body.bounce.set(1);

		this.floorGroup=game.add.group();

	    this.floorGroup.enableBody = true;
	    this.floorGroup.physicsBodyType = Phaser.Physics.ARCADE;

	    for(i=0; i<2; i++)	{
			let t= this.floorGroup.create(i*200,500,'floor');
			t.body.allowGravity=false;
			t.body.immovable=true;
		}
			let t= this.floorGroup.create(400,200,'floor');
			t.body.allowGravity=false;
			t.body.immovable=true;
    game.camera.follow(this.player, Phaser.Camera.FOLLOW_LOCKON, 0.1, 0.1);
    //game.camera.x -= 4;

    	this.item=game.add.sprite(0,200,'item');
		game.physics.enable(this.item, Phaser.Physics.ARCADE);

    			this.item.body.allowGravity=false;
			this.item.body.immovable=true;


		this.style={font:"50px Arial",fill:"#000"};
		this.text=game.add.text(0,0,"Item : 0",this.style);
		this.text.fixedToCamera=true;
		this.itemNum=0;

		this.effectList=[];
	},
	update: function()	{
		game.physics.arcade.collide(this.player, this.floorGroup);
		game.physics.arcade.collide(this.player, this.item, function(p,i){
			if(p.body.touching.up && i.body.touching.down)	{
				this.itemNum++;
				this.text.setText("Item : "+this.itemNum);
				let t=game.add.image(i.x+i.width/2,i.y+25,'effect');
				t.anchor.setTo(0.5);
				this.effectList.push(t);
			}
		},null,this);
	    this.player.body.velocity.x=0;

	    if (game.input.keyboard.isDown(Phaser.Keyboard.LEFT))
	    {
	    	this.player.body.velocity.x=-150;
	    }
	    else if (game.input.keyboard.isDown(Phaser.Keyboard.RIGHT))
	    {
	    	this.player.body.velocity.x=150;
	    }
	    if(game.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)&&
	    	(this.player.body.touching.down || this.player.body.onFloor()))	{
	    		this.player.body.velocity.y=-1500;
	    }

	    for(let i in this.effectList)	{
	    	this.effectList[i].y-=150*game.time.physicsElapsed;
	    	this.effectList[i].alpha-=1.5*game.time.physicsElapsed;
	    	this.effectList[i].rotation+=2*Math.PI*game.time.physicsElapsed;
	    }
	}
};



game.state.add('TEST',TEST);

game.state.start('TEST');